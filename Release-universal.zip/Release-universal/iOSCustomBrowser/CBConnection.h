//
//  CBConnection.h
//  PayUTestApp
//
//  Created by Umang Arya on 20/07/15.
//  Copyright (c) 2015 PayU, India. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CBCustomActivityIndicator.h"
#import "CBConnectionHandler.h"
#import "CBAllPaymentOption.h"


@interface CBConnection : NSObject


@property (nonatomic, assign) BOOL isWKWebView;
@property (nonatomic, copy) NSString *cbServerID;
@property (nonatomic, copy) NSString *analyticsServerID;
@property (nonatomic, copy) NSString *txnID;
@property (nonatomic, copy) NSString *merchantKey;

@property (nonatomic, assign) BOOL isAutoOTPSelect;
//@property (nonatomic, assign) BOOL isAutoApproveClick;

- (instancetype)init:(UIView *)view webView:(UIWebView *) webView;
- (void)payUActivityIndicator;
- (void)initialSetup;
- (void)payUwebView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request;
- (void)payUwebView:(UIWebView *)webView didFailLoadWithError:(NSError *)error;
- (void)payUwebViewDidFinishLoad:(UIWebView *)webView;

- (void)transactionStatus:(BOOL)success;
- (void)logTxnTerminateEvent;
//- (void)deallocHandler;

@end
