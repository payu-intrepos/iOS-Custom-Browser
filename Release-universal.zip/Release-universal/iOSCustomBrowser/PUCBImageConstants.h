//
//  PUCBImageConstants.h
//  PayUNonSeamlessTestApp
//
//  Created by Umang Arya on 3/14/16.
//  Copyright © 2016 PayU. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PUCBImageConstants : NSObject

extern NSString  * const PUCBLoader1, * const PUCBLoader2, * const PUCBLoader3, * const PUCBLoader4;
extern NSString  * const PUCBLogo, * const PUCBReloadIcon, * const PUCBBackButton;

@end
