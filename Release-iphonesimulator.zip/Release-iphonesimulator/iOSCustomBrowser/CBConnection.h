//
//  CBConnection.h
//  PayUTestApp
//
//  Created by Umang Arya on 20/07/15.
//  Copyright (c) 2015 PayU, India. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CustomActivityIndicator.h"
#import "CBConnectionHandler.h"
#import "CBAllPaymentOption.h"


@interface CBConnection : NSObject

@property (strong,nonatomic) UIView *transparentView;
@property (nonatomic,strong) NSArray *pgUrlList;
@property (nonatomic,strong) CBConnectionHandler *handler;
@property (nonatomic,strong) NSString *loadingUrl;
@property (nonatomic,strong) CustomActivityIndicator *customIndicator;
@property (nonatomic,assign) float y;
@property (nonatomic,assign) BOOL isBankFound;

-(void)loadPayuActivityIndicator;
- (instancetype)init:(UIView *)view webView:(UIWebView *) webView;
-(BOOL)payUWebView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request;
- (void)payUWebViewDidFinishLoad:(UIWebView *)webView;
-(void)deallocHandler;
-(void) InitialSetup;

@end
